# Local Video Studio 中文单卡版

适用环境：

- Ubuntu 20.04
- 单张 NVIDIA RTX 6000D
- 64GB 系统内存
- 已安装 Python 3.11、CUDA 版 PyTorch、torchvision、torchaudio
- ComfyUI 目录默认为 `~/SD/ComfyUI`
- 所有模型、提示词处理、图片和视频生成都在本地完成

## 中文支持方案

### 文生图

默认图片模型为 `FLUX.1 Schnell FP8`。

FLUX 可以接受 Unicode 文本，但官方模型说明主要以英文 Prompt 为基准。因此本项目提供一个本地 Qwen2.5-3B-Instruct 提示词优化器：

```text
用户输入中文
→ 本地 Qwen 整理并翻译成 FLUX 英文视觉提示词
→ FLUX 生成图片
```

网页仍然只需要输入中文。优化后的提示词会在网页上显示，用户可以在提交前修改。

### 文生视频、图生视频

默认视频模型为 `Wan2.2 TI2V 5B`。Wan 模型支持中文和英文，网页默认保持中文，并通过本地 Qwen 将描述整理为：

```text
主体 + 场景 + 动作 + 镜头运动 + 光线 + 稳定性约束
```

不依赖任何云端翻译或生成 API。

## 推荐模型

| 功能 | 模型 | 目录 |
|---|---|---|
| 文生图、四视角 | FLUX.1 Schnell FP8 | `models/checkpoints/` |
| 文生视频、图生视频 | Wan2.2 TI2V 5B FP16 | `models/diffusion_models/` |
| Wan 文本编码器 | UMT5-XXL FP8 | `models/text_encoders/` |
| Wan VAE | Wan2.2 VAE | `models/vae/` |
| 中文提示词优化 | Qwen2.5-3B-Instruct | `models/prompt_optimizer/` |

## 安装顺序

### 1. 解压

```bash
unzip LocalVideoStudio_中文单卡版.zip
cd LocalVideoStudio_中文单卡版
chmod +x scripts/*.sh
```

### 2. 接管现有 ComfyUI

你的 ComfyUI 位于 `~/SD/ComfyUI` 时：

```bash
./scripts/setup_existing_comfyui.sh "$HOME/SD/ComfyUI"
```

脚本不会卸载或重装现有 PyTorch，只安装 ComfyUI 其余依赖、自定义节点、前端环境和服务模板。

### 3. 下载模型

服务器能访问 Hugging Face：

```bash
./scripts/download_models.sh "$HOME/SD/ComfyUI"
```

使用 Hugging Face 镜像：

```bash
export HF_ENDPOINT=https://hf-mirror.com
./scripts/download_models.sh "$HOME/SD/ComfyUI"
```

只下载图像和视频模型，不下载 Qwen：

```bash
SKIP_PROMPT_OPTIMIZER=1 ./scripts/download_models.sh "$HOME/SD/ComfyUI"
```

### 4. 启动测试

```bash
./scripts/start_comfyui.sh "$HOME/SD/ComfyUI"
```

访问：

```text
http://服务器IP:8188
```

### 5. 准备三个工作流

在 ComfyUI 中分别加载官方模板并跑通：

- FLUX.1 Schnell FP8
- Wan2.2 5B 文生视频
- Wan2.2 5B 图生视频

在设置中开启开发者模式，然后选择：

```text
Save (API Format)
```

导出为：

```text
frontend/workflows/multiview_api.json
frontend/workflows/text_to_video_api.json
frontend/workflows/image_to_video_api.json
```

然后运行自动映射工具：

```bash
python3 scripts/configure_workflows.py \
  --frontend frontend \
  --multiview frontend/workflows/multiview_api.json \
  --t2v frontend/workflows/text_to_video_api.json \
  --i2v frontend/workflows/image_to_video_api.json
```

工具会自动寻找常见的文本、采样器和 LoadImage 节点；如有多个候选，会输出候选节点供人工选择。

### 6. 启动中文前端

```bash
./scripts/start_frontend.sh "$HOME/SD/ComfyUI"
```

访问：

```text
http://服务器IP:8080
```

## 单卡运行策略

只有一个 ComfyUI 实例。图片和视频任务进入同一队列，不并行运行：

```text
中文网页 :8080
       ↓
ComfyUI :8188
       ↓
RTX 6000D
```

推荐参数：

### FLUX

```yaml
resolution: 1024x1024
steps: 4
batch: 1
```

四视角按四个任务依次执行，不使用 batch=4。

### Wan2.2 5B

```yaml
resolution: 832x480
frames: 49
fps: 16
steps: 20
```

稳定后再把帧数提高到 81。64GB RAM 下不建议默认使用 Wan 14B 双专家版本。

## Swap

建议增加 32GB swap 防止模型切换时被 OOM Killer 杀掉：

```bash
sudo fallocate -l 32G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

## 输出目录

```text
ComfyUI/output/views/
ComfyUI/output/videos/
```

## 完全离线

模型、Python 依赖和节点下载完成后，可断开互联网。前端只连接：

```text
http://127.0.0.1:8188
```

Qwen 优化器也读取服务器本地模型目录，不调用网络 API。
