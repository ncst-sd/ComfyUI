#!/usr/bin/env bash
set -euo pipefail
COMFY="${1:-$HOME/SD/ComfyUI}"
files=(
  "$COMFY/models/checkpoints/flux1-schnell-fp8.safetensors"
  "$COMFY/models/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors"
  "$COMFY/models/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"
  "$COMFY/models/vae/wan2.2_vae.safetensors"
  "$COMFY/models/prompt_optimizer/Qwen2.5-3B-Instruct/config.json"
)
missing=0
for f in "${files[@]}"; do
  if [[ -e "$f" ]]; then
    du -h "$f" 2>/dev/null | head -n1
  else
    echo "缺失：$f"
    missing=1
  fi
done
exit "$missing"
