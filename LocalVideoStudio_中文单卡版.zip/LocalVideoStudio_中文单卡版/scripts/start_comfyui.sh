#!/usr/bin/env bash
set -euo pipefail
COMFY="${1:-$HOME/SD/ComfyUI}"
cd "$COMFY"
source venv/bin/activate
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
exec python main.py \
  --listen 0.0.0.0 \
  --port 8188 \
  --preview-method auto
