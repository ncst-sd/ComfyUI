import json, sys
from pathlib import Path

path = Path(sys.argv[1])
comfy = Path(sys.argv[2]).resolve()
data = json.loads(path.read_text(encoding="utf-8"))
data["image_server"] = "http://127.0.0.1:8188"
data["video_server"] = "http://127.0.0.1:8188"
data["comfyui_dir"] = str(comfy)
data["prompt_optimizer_model"] = str(
    comfy / "models/prompt_optimizer/Qwen2.5-3B-Instruct"
)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"已更新 {path}")
