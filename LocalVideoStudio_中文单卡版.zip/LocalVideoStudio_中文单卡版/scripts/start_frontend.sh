#!/usr/bin/env bash
set -euo pipefail
COMFY="${1:-$HOME/SD/ComfyUI}"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PKG/frontend"
source venv/bin/activate
export FRONTEND_CONFIG="$PKG/frontend/config.json"
export COMFYUI_DIR="$COMFY"
exec uvicorn app.main:app --host 0.0.0.0 --port 8080
