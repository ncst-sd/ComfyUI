#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

TEXT_CLASSES = {"CLIPTextEncode", "CLIPTextEncodeFlux", "WanVideoTextEncode"}
SAMPLER_CLASSES = {"KSampler", "KSamplerAdvanced", "SamplerCustom", "SamplerCustomAdvanced"}
LOAD_IMAGE_CLASSES = {"LoadImage"}

def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def candidates(wf, classes):
    result=[]
    for node_id,node in wf.items():
        if not isinstance(node,dict): continue
        cls=node.get("class_type","")
        if cls in classes or any(x.lower() in cls.lower() for x in classes):
            result.append((str(node_id),cls,node.get("inputs",{})))
    return result

def choose(items, preferred_input):
    exact=[x for x in items if preferred_input in x[2]]
    return exact[0] if len(exact)==1 else (items[0] if len(items)==1 else None)

def configure(cfg, name, path, is_image=False):
    wf=load(path)
    texts=candidates(wf,TEXT_CLASSES)
    samplers=candidates(wf,SAMPLER_CLASSES)
    images=candidates(wf,LOAD_IMAGE_CLASSES)

    print(f"\n{name}:")
    print("文本候选:", [(x[0],x[1],list(x[2])) for x in texts])
    print("采样候选:", [(x[0],x[1],list(x[2])) for x in samplers])
    if is_image:
        print("图片候选:", [(x[0],x[1],list(x[2])) for x in images])

    t=choose(texts,"text")
    s=choose(samplers,"seed")
    if t:
        cfg["workflows"][name]["fields"]["prompt"]={"node":t[0],"input":"text"}
    if s:
        cfg["workflows"][name]["fields"]["seed"]={"node":s[0],"input":"seed"}
        if "steps" in s[2] and "steps" in cfg["workflows"][name]["fields"]:
            cfg["workflows"][name]["fields"]["steps"]={"node":s[0],"input":"steps"}
    if is_image:
        i=choose(images,"image")
        if i:
            cfg["workflows"][name]["upload_field"]={"node":i[0],"input":"image"}

    cfg["workflows"][name]["file"]=f"workflows/{Path(path).name}"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--frontend",required=True)
    ap.add_argument("--multiview",required=True)
    ap.add_argument("--t2v",required=True)
    ap.add_argument("--i2v",required=True)
    a=ap.parse_args()
    frontend=Path(a.frontend)
    cfg_path=frontend/"config.json"
    if not cfg_path.exists():
        cfg_path=frontend/"config.example.json"
    cfg=json.loads(cfg_path.read_text(encoding="utf-8"))
    configure(cfg,"multiview",a.multiview)
    configure(cfg,"text_to_video",a.t2v)
    configure(cfg,"image_to_video",a.i2v,True)
    out=frontend/"config.json"
    out.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"\n已写入 {out}")
    print("如果某项仍为占位符，请根据上面候选节点手动修改。")

if __name__=="__main__":
    main()
