#!/usr/bin/env bash
set -euo pipefail

COMFY="${1:-$HOME/SD/ComfyUI}"
if [[ ! -f "$COMFY/venv/bin/activate" ]]; then
  echo "找不到 $COMFY/venv"
  exit 1
fi

source "$COMFY/venv/bin/activate"
python -m pip install --upgrade huggingface_hub hf_transfer \
  --timeout 600 --retries 10

export HF_HUB_ENABLE_HF_TRANSFER="${HF_HUB_ENABLE_HF_TRANSFER:-1}"

CKPT="$COMFY/models/checkpoints"
DM="$COMFY/models/diffusion_models"
TE="$COMFY/models/text_encoders"
VAE="$COMFY/models/vae"
OPT="$COMFY/models/prompt_optimizer"
mkdir -p "$CKPT" "$DM" "$TE" "$VAE" "$OPT"

download_file() {
  local repo="$1"
  local remote="$2"
  local destination="$3"
  echo "下载 $repo / $remote"
  local tmp
  tmp="$(mktemp -d)"
  hf download "$repo" "$remote" --local-dir "$tmp"
  local src="$tmp/$remote"
  if [[ ! -f "$src" ]]; then
    echo "下载结果中未找到 $remote"
    rm -rf "$tmp"
    return 1
  fi
  mkdir -p "$(dirname "$destination")"
  mv "$src" "$destination"
  rm -rf "$tmp"
}

# FLUX 一体化 FP8 checkpoint
download_file \
  Comfy-Org/flux1-schnell \
  flux1-schnell-fp8.safetensors \
  "$CKPT/flux1-schnell-fp8.safetensors"

# Wan2.2 TI2V 5B
download_file \
  Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors \
  "$DM/wan2.2_ti2v_5B_fp16.safetensors"

download_file \
  Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors \
  "$TE/umt5_xxl_fp8_e4m3fn_scaled.safetensors"

download_file \
  Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/vae/wan2.2_vae.safetensors \
  "$VAE/wan2.2_vae.safetensors"

if [[ "${SKIP_PROMPT_OPTIMIZER:-0}" != "1" ]]; then
  echo "下载本地中文提示词优化器 Qwen2.5-3B-Instruct"
  hf download Qwen/Qwen2.5-3B-Instruct \
    --local-dir "$OPT/Qwen2.5-3B-Instruct"
fi

echo "下载完成。"
"$PWD/scripts/check_models.sh" "$COMFY" 2>/dev/null || true
