#!/usr/bin/env bash
set -euo pipefail

COMFY="${1:-$HOME/SD/ComfyUI}"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -f "$COMFY/main.py" ]]; then
  echo "未找到 ComfyUI：$COMFY"
  exit 1
fi
if [[ ! -f "$COMFY/venv/bin/activate" ]]; then
  echo "未找到虚拟环境：$COMFY/venv"
  exit 2
fi

source "$COMFY/venv/bin/activate"

echo "检查现有 PyTorch，脚本不会卸载或替换它："
python - <<'PY'
import torch
print("torch:", torch.__version__)
print("CUDA runtime:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
if not torch.cuda.is_available():
    raise SystemExit("当前 PyTorch 无法使用 CUDA")
print("GPU:", torch.cuda.get_device_name(0))
PY

# 普通 Python 包使用已配置的 pip 源。排除 torch 三件套，避免覆盖 CUDA 版本。
grep -Ev '^(torch|torchvision|torchaudio)([<>=~! ]|$)' \
  "$COMFY/requirements.txt" > /tmp/comfy-requirements-no-torch.txt

python -m pip install --upgrade pip setuptools wheel
python -m pip install -r /tmp/comfy-requirements-no-torch.txt \
  --timeout 600 --retries 10

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  git git-lfs ffmpeg libgl1 libglib2.0-0 libsm6 libxext6 libxrender1

NODES="$COMFY/custom_nodes"
mkdir -p "$NODES"

install_node() {
  local url="$1"
  local name
  name="$(basename "$url" .git)"
  if [[ -d "$NODES/$name/.git" ]]; then
    git -C "$NODES/$name" pull --ff-only
  else
    git clone --depth 1 "$url" "$NODES/$name"
  fi
  if [[ -f "$NODES/$name/requirements.txt" ]]; then
    # 防止第三方节点 requirements 覆盖 torch
    grep -Ev '^(torch|torchvision|torchaudio)([<>=~! ]|$)' \
      "$NODES/$name/requirements.txt" > "/tmp/${name}-requirements-no-torch.txt" || true
    if [[ -s "/tmp/${name}-requirements-no-torch.txt" ]]; then
      python -m pip install -r "/tmp/${name}-requirements-no-torch.txt" \
        --timeout 600 --retries 10
    fi
  fi
}

# 优先使用 ComfyUI 原生 FLUX/Wan 节点，只安装必要的视频输出和工具节点。
install_node https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git
install_node https://github.com/kijai/ComfyUI-KJNodes.git

mkdir -p \
  "$COMFY/models/checkpoints" \
  "$COMFY/models/diffusion_models" \
  "$COMFY/models/text_encoders" \
  "$COMFY/models/vae" \
  "$COMFY/models/prompt_optimizer" \
  "$COMFY/output/views" \
  "$COMFY/output/videos" \
  "$COMFY/input"

# 前端独立 venv，避免影响 ComfyUI Python 环境。
cd "$PKG/frontend"
python3.11 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt --timeout 600 --retries 10
cp -n config.example.json config.json || true

python3 "$PKG/scripts/patch_frontend_config.py" \
  "$PKG/frontend/config.json" "$COMFY"

echo
echo "基础配置完成。下一步："
echo "  $PKG/scripts/download_models.sh \"$COMFY\""
echo "  $PKG/scripts/start_comfyui.sh \"$COMFY\""
