#!/usr/bin/env bash
set -euo pipefail
COMFY="${1:-$HOME/SD/ComfyUI}"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
USER_NAME="${SUDO_USER:-$USER}"
sudo sed "s|__USER__|$USER_NAME|g;s|__COMFY__|$COMFY|g" \
  "$PKG/systemd/local-video-comfyui.service" \
  | sudo tee /etc/systemd/system/local-video-comfyui.service >/dev/null
sudo sed "s|__USER__|$USER_NAME|g;s|__COMFY__|$COMFY|g;s|__PKG__|$PKG|g" \
  "$PKG/systemd/local-video-frontend.service" \
  | sudo tee /etc/systemd/system/local-video-frontend.service >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable --now local-video-comfyui local-video-frontend
echo "网页：http://服务器IP:8080"
