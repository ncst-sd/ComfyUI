from __future__ import annotations
import asyncio, copy, json, mimetypes, os, sys, uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR=Path(__file__).resolve().parent.parent
CONFIG_PATH=Path(os.environ.get("FRONTEND_CONFIG",BASE_DIR/"config.json"))
if not CONFIG_PATH.exists(): CONFIG_PATH=BASE_DIR/"config.example.json"
CONFIG=json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
app=FastAPI(title=CONFIG.get("title","本地中文生成工作台"))
app.mount("/static",StaticFiles(directory=BASE_DIR/"app/static"),name="static")

def server_url(kind):
    return CONFIG["image_server" if kind=="image" else "video_server"].rstrip("/")

def workflow_cfg(name):
    cfg=CONFIG.get("workflows",{}).get(name)
    if not cfg: raise HTTPException(404,f"未知工作流：{name}")
    return cfg

def load_workflow(cfg):
    path=BASE_DIR/cfg["file"]
    if not path.exists(): raise HTTPException(422,f"工作流不存在：{path}")
    data=json.loads(path.read_text(encoding="utf-8"))
    if "_说明" in data: raise HTTPException(422,"请先用 ComfyUI 的 Save (API Format) 替换工作流占位文件")
    return data

def set_value(wf,mapping,value):
    node=str(mapping["node"]); key=mapping["input"]
    if node not in wf: raise HTTPException(422,f"工作流中不存在节点 {node}")
    if key not in wf[node].setdefault("inputs",{}):
        raise HTTPException(422,f"节点 {node} 没有输入字段 {key}")
    wf[node]["inputs"][key]=value

async def comfy_json(method,url,**kwargs):
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            r=await client.request(method,url,**kwargs); r.raise_for_status(); return r.json()
    except httpx.ConnectError as e:
        raise HTTPException(503,f"无法连接本地 ComfyUI：{url}") from e
    except httpx.HTTPStatusError as e:
        raise HTTPException(e.response.status_code,e.response.text[:2000]) from e

class OptimizeRequest(BaseModel):
    workflow:str
    prompt:str

class SubmitRequest(BaseModel):
    workflow:str
    prompt:str=""
    negative_prompt:str=""
    seed:int|None=None
    steps:int|None=None
    optimize:bool=True

async def optimize_prompt(workflow,prompt):
    cfg=workflow_cfg(workflow)
    if not CONFIG.get("prompt_optimizer_enabled",True) or not prompt.strip():
        return prompt
    model=Path(CONFIG.get("prompt_optimizer_model","")).expanduser()
    if not (model/"config.json").exists():
        return prompt
    worker=BASE_DIR/"app/prompt_optimizer_worker.py"
    proc=await asyncio.create_subprocess_exec(
        sys.executable,str(worker),"--model",str(model),
        "--mode",cfg.get("prompt_mode","video_chinese"),
        "--prompt",prompt,
        stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE
    )
    out,err=await proc.communicate()
    if proc.returncode!=0:
        raise HTTPException(500,f"本地提示词优化失败：{err.decode(errors='ignore')[-1000:]}")
    data=json.loads(out.decode())
    return data.get("prompt",prompt) if data.get("ok") else prompt

@app.get("/",response_class=HTMLResponse)
async def index(): return FileResponse(BASE_DIR/"app/static/index.html")

@app.get("/api/config")
async def get_config():
    return {
        "title":CONFIG.get("title"),
        "poll_interval_ms":CONFIG.get("poll_interval_ms",1500),
        "optimizer_enabled":CONFIG.get("prompt_optimizer_enabled",True),
        "workflows":{k:{"label":v.get("label",k),"server":v.get("server")}
                     for k,v in CONFIG.get("workflows",{}).items()}
    }

@app.get("/api/health")
async def health():
    try:
        stats=await comfy_json("GET",f"{server_url('image')}/system_stats")
        comfy={"ok":True,"stats":stats}
    except HTTPException as e:
        comfy={"ok":False,"error":e.detail}
    model=Path(CONFIG.get("prompt_optimizer_model","")).expanduser()
    return {"comfyui":comfy,"optimizer":{"ok":(model/"config.json").exists(),"model":str(model)}}

@app.post("/api/optimize")
async def optimize(req:OptimizeRequest):
    result=await optimize_prompt(req.workflow,req.prompt)
    return {"original":req.prompt,"optimized":result}

@app.post("/api/submit")
async def submit(req:SubmitRequest):
    cfg=workflow_cfg(req.workflow)
    wf=copy.deepcopy(load_workflow(cfg))
    prompt=await optimize_prompt(req.workflow,req.prompt) if req.optimize else req.prompt
    values=req.model_dump(exclude={"workflow","optimize"},exclude_none=True)
    values["prompt"]=prompt
    for field,value in values.items():
        mapping=cfg.get("fields",{}).get(field)
        if mapping and value!="": set_value(wf,mapping,value)
    client_id=str(uuid.uuid4())
    queued=await comfy_json("POST",f"{server_url(cfg['server'])}/prompt",
                            json={"prompt":wf,"client_id":client_id})
    return {"workflow":req.workflow,"server":cfg["server"],
            "prompt_id":queued["prompt_id"],"queue_number":queued.get("number"),
            "client_id":client_id,"optimized_prompt":prompt}

@app.post("/api/submit-image")
async def submit_image(
    workflow:str=Form(...),prompt:str=Form(""),seed:int|None=Form(None),
    optimize:bool=Form(True),image:UploadFile=File(...)
):
    cfg=workflow_cfg(workflow)
    if "upload_field" not in cfg: raise HTTPException(422,"该工作流未配置图片输入")
    target=server_url(cfg["server"])
    content=await image.read()
    if len(content)>50*1024*1024: raise HTTPException(413,"图片不能超过 50MB")
    safe=f"{uuid.uuid4().hex}_{Path(image.filename or 'input.png').name}"
    async with httpx.AsyncClient(timeout=120) as client:
        r=await client.post(f"{target}/upload/image",
            files={"image":(safe,content,image.content_type or "application/octet-stream")},
            data={"type":"input","overwrite":"true"})
        r.raise_for_status(); uploaded=r.json()
    wf=copy.deepcopy(load_workflow(cfg))
    set_value(wf,cfg["upload_field"],uploaded["name"])
    final_prompt=await optimize_prompt(workflow,prompt) if optimize else prompt
    if final_prompt and cfg.get("fields",{}).get("prompt"):
        set_value(wf,cfg["fields"]["prompt"],final_prompt)
    if seed is not None and cfg.get("fields",{}).get("seed"):
        set_value(wf,cfg["fields"]["seed"],seed)
    client_id=str(uuid.uuid4())
    queued=await comfy_json("POST",f"{target}/prompt",
        json={"prompt":wf,"client_id":client_id})
    return {"workflow":workflow,"server":cfg["server"],
            "prompt_id":queued["prompt_id"],"queue_number":queued.get("number"),
            "client_id":client_id,"optimized_prompt":final_prompt}

def collect_outputs(item,kind):
    found=[]
    for node_id,out in item.get("outputs",{}).items():
        for category in ("images","gifs","videos","audio"):
            for f in out.get(category,[]) or []:
                if not isinstance(f,dict) or "filename" not in f: continue
                ext=Path(f["filename"]).suffix.lower()
                media="video" if ext in {".mp4",".webm",".mov",".mkv"} else "image"
                q=urlencode({"server":kind,"filename":f["filename"],
                    "subfolder":f.get("subfolder",""),"type":f.get("type","output")})
                found.append({"node_id":node_id,"media_type":media,
                              "filename":f["filename"],"url":f"/api/media?{q}"})
    return found

@app.get("/api/job/{server_kind}/{prompt_id}")
async def job(server_kind,prompt_id):
    target=server_url(server_kind)
    history=await comfy_json("GET",f"{target}/history/{prompt_id}")
    item=history.get(prompt_id)
    if not item:
        queue=await comfy_json("GET",f"{target}/queue")
        rows=queue.get("queue_running",[])+queue.get("queue_pending",[])
        return {"done":False,"running":any(str(r[1])==prompt_id for r in rows),"outputs":[]}
    status=item.get("status",{})
    return {"done":bool(status.get("completed",True)),"status":status,
            "outputs":collect_outputs(item,server_kind)}

@app.get("/api/media")
async def media(server:str,filename:str,subfolder:str="",type:str="output"):
    async with httpx.AsyncClient(timeout=120) as client:
        r=await client.get(f"{server_url(server)}/view",
                           params={"filename":filename,"subfolder":subfolder,"type":type})
        r.raise_for_status()
    ct=r.headers.get("content-type") or mimetypes.guess_type(filename)[0]
    return Response(r.content,media_type=ct or "application/octet-stream")

@app.post("/api/interrupt/{server_kind}")
async def interrupt(server_kind):
    return await comfy_json("POST",f"{server_url(server_kind)}/interrupt",json={})
