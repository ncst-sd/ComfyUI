from __future__ import annotations
import argparse, json
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

SYSTEM_IMAGE = """你是图像生成提示词工程师。用户只会输入中文。
把用户描述转换成一段适合 FLUX 文生图模型的高质量英文提示词。
必须保留所有主体、数量、颜色、材质、空间关系、视角和文字要求。
只输出最终英文提示词，不解释，不加引号。"""

SYSTEM_VIDEO = """你是 Wan 视频生成提示词工程师。
把用户中文描述整理成自然、明确的中文视频提示词，顺序为：
主体与环境、主体动作、镜头运动、光线和风格、稳定性约束。
不要增加用户没有要求的主体或剧情。只输出最终中文提示词。"""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--model",required=True)
    ap.add_argument("--mode",choices=["image_translate","video_chinese"],required=True)
    ap.add_argument("--prompt",required=True)
    args=ap.parse_args()

    model_path=Path(args.model).expanduser()
    if not (model_path/"config.json").exists():
        print(json.dumps({"ok":False,"error":"本地 Qwen 模型不存在"},ensure_ascii=False))
        return

    tokenizer=AutoTokenizer.from_pretrained(model_path,local_files_only=True)
    model=AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float32,
        device_map="cpu",
        local_files_only=True,
        low_cpu_mem_usage=True,
    )
    system=SYSTEM_IMAGE if args.mode=="image_translate" else SYSTEM_VIDEO
    messages=[{"role":"system","content":system},{"role":"user","content":args.prompt}]
    text=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
    inputs=tokenizer([text],return_tensors="pt")
    with torch.inference_mode():
        output=model.generate(
            **inputs,max_new_tokens=320,do_sample=False,
            repetition_penalty=1.05,pad_token_id=tokenizer.eos_token_id
        )
    generated=output[0][inputs.input_ids.shape[1]:]
    result=tokenizer.decode(generated,skip_special_tokens=True).strip()
    print(json.dumps({"ok":True,"prompt":result},ensure_ascii=False))

if __name__=="__main__":
    main()
