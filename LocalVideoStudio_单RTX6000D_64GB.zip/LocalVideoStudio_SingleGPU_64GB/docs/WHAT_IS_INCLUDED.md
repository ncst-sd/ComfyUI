# 包含内容

- 单 GPU ComfyUI 安装与启动脚本
- FastAPI + HTML/JS 前端
- FLUX.1 Schnell FP8 下载配置
- Wan2.2 TI2V 5B 下载配置
- Wan2.1 1.3B 保底下载选项
- 图片、I2V、T2V 三个 API 工作流槽位
- systemd 服务
- 硬件、RAM、CUDA、模型完整性诊断
- 本地图片显示与本地视频播放器

模型权重本身不在压缩包内。推荐模型总大小很大，安装脚本会下载到服务器本地，之后可完全离线运行。
