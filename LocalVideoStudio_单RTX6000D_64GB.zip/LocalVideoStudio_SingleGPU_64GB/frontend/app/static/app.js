
let mode = "multiview";
let currentJob = null;
let pollTimer = null;
let config = null;

const $ = (id) => document.getElementById(id);
const statusBadge = $("statusBadge");
const gallery = $("gallery");

function setStatus(text, cls, info) {
  statusBadge.textContent = text;
  statusBadge.className = `badge ${cls}`;
  if (info !== undefined) $("jobInfo").textContent = info;
}
function setProgress(v) { $("progressBar").style.width = `${v}%`; }

async function init() {
  config = await fetch("/api/config").then(r => r.json());
  $("title").textContent = config.title || "AI 视频生成工作台";
  await checkHealth();
  setInterval(checkHealth, 10000);
}
async function checkHealth() {
  try {
    const h = await fetch("/api/health").then(r => r.json());
    const i = h.image.ok ? "图像 GPU ✓" : "图像 GPU ×";
    const v = h.video.ok ? "视频 GPU ✓" : "视频 GPU ×";
    $("health").textContent = `${i} · ${v}`;
  } catch {
    $("health").textContent = "前端服务异常";
  }
}

document.querySelectorAll(".tab").forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll(".tab").forEach(x => x.classList.remove("active"));
    btn.classList.add("active");
    mode = btn.dataset.mode;
    $("uploadWrap").classList.toggle("hidden", mode !== "image_to_video");
    $("negativeWrap").classList.toggle("hidden", mode === "image_to_video");
    $("stepsWrap").classList.toggle("hidden", mode === "image_to_video");
  };
});

$("image").onchange = e => {
  const file = e.target.files[0];
  if (!file) return;
  $("uploadPreview").src = URL.createObjectURL(file);
  $("uploadPreview").classList.remove("hidden");
};

$("jobForm").onsubmit = async e => {
  e.preventDefault();
  $("submitBtn").disabled = true;
  setStatus("正在提交", "running", "正在发送工作流到 ComfyUI…");
  setProgress(8);
  try {
    let resp;
    if (mode === "image_to_video") {
      const file = $("image").files[0];
      if (!file) throw new Error("请先选择首帧图片");
      const fd = new FormData();
      fd.append("workflow", mode);
      fd.append("prompt", $("prompt").value);
      fd.append("seed", $("seed").value);
      fd.append("image", file);
      resp = await fetch("/api/submit-image", {method: "POST", body: fd});
    } else {
      resp = await fetch("/api/submit", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          workflow: mode,
          prompt: $("prompt").value,
          negative_prompt: $("negative").value,
          seed: Number($("seed").value),
          steps: Number($("steps").value)
        })
      });
    }
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || JSON.stringify(data));
    currentJob = data;
    setStatus("队列中", "running",
      `任务 ID：${data.prompt_id}\n执行服务器：${data.server === "image" ? "GPU 0 / 8188" : "GPU 1 / 8189"}\n队列序号：${data.queue_number ?? "-"}`);
    setProgress(18);
    startPolling();
  } catch (err) {
    setStatus("提交失败", "error", err.message);
    setProgress(0);
  } finally {
    $("submitBtn").disabled = false;
  }
};

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  let fakeProgress = 18;
  pollTimer = setInterval(async () => {
    if (!currentJob) return;
    try {
      const r = await fetch(`/api/job/${currentJob.server}/${currentJob.prompt_id}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.detail || "查询任务失败");

      if (!data.done) {
        fakeProgress = Math.min(88, fakeProgress + (data.running ? 4 : 1));
        setProgress(fakeProgress);
        setStatus(data.running ? "生成中" : "队列中", "running",
          `任务 ID：${currentJob.prompt_id}\n${data.running ? "模型正在生成，请保持页面打开。" : "正在等待 GPU 队列。"}`);
        return;
      }

      clearInterval(pollTimer);
      pollTimer = null;
      setProgress(100);
      setStatus("已完成", "done", `任务完成，共返回 ${data.outputs.length} 个文件。`);
      renderOutputs(data.outputs);
    } catch (err) {
      clearInterval(pollTimer);
      pollTimer = null;
      setStatus("执行异常", "error", err.message);
    }
  }, config?.poll_interval_ms || 1500);
}

function renderOutputs(outputs) {
  if (!outputs.length) {
    gallery.innerHTML = `<div class="empty">任务完成，但历史记录中没有找到媒体文件。请检查 SaveImage 或 Video Combine 输出节点。</div>`;
    return;
  }
  const empty = gallery.querySelector(".empty");
  if (empty) gallery.innerHTML = "";
  outputs.forEach(o => {
    const card = document.createElement("article");
    card.className = "card";
    const media = o.media_type === "video"
      ? `<video controls preload="metadata" src="${o.url}"></video>`
      : `<a href="${o.url}" target="_blank"><img loading="lazy" src="${o.url}" alt="${o.filename}"></a>`;
    card.innerHTML = `${media}<footer>${o.filename}</footer>`;
    gallery.prepend(card);
  });
}

$("interruptBtn").onclick = async () => {
  const server = currentJob?.server || (mode === "multiview" ? "image" : "video");
  await fetch(`/api/interrupt/${server}`, {method: "POST"});
  if (pollTimer) clearInterval(pollTimer);
  setStatus("已请求停止", "error", "已向对应 ComfyUI 实例发送中断请求。");
  setProgress(0);
};

$("clearBtn").onclick = () => {
  gallery.innerHTML = `<div class="empty">生成的图片和视频会显示在这里。</div>`;
};

init();
