
from __future__ import annotations

import copy
import json
import mimetypes
import os
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = Path(os.environ.get("FRONTEND_CONFIG", BASE_DIR / "config.json"))
if not CONFIG_PATH.exists():
    CONFIG_PATH = BASE_DIR / "config.example.json"

CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
app = FastAPI(title=CONFIG.get("title", "ComfyUI Frontend"))
app.mount("/static", StaticFiles(directory=BASE_DIR / "app" / "static"), name="static")


def server_url(kind: str) -> str:
    key = "image_server" if kind == "image" else "video_server"
    return CONFIG[key].rstrip("/")


def workflow_cfg(name: str) -> dict[str, Any]:
    cfg = CONFIG.get("workflows", {}).get(name)
    if not cfg:
        raise HTTPException(404, f"未知工作流：{name}")
    return cfg


def load_workflow(cfg: dict[str, Any]) -> dict[str, Any]:
    path = BASE_DIR / cfg["file"]
    if not path.exists():
        raise HTTPException(
            422,
            f"工作流文件不存在：{path.name}。请从 ComfyUI 使用 Save (API Format) 导出后替换该文件。"
        )
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise HTTPException(422, f"工作流 JSON 无效：{exc}") from exc


def set_mapped_value(workflow: dict[str, Any], mapping: dict[str, str], value: Any) -> None:
    node_id = str(mapping["node"])
    input_name = mapping["input"]
    if node_id not in workflow:
        raise HTTPException(422, f"映射节点 {node_id} 不存在，请修改 config.json")
    inputs = workflow[node_id].setdefault("inputs", {})
    if input_name not in inputs:
        raise HTTPException(422, f"节点 {node_id} 没有输入字段 {input_name}")
    inputs[input_name] = value


async def comfy_json(method: str, url: str, **kwargs) -> Any:
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
    except httpx.ConnectError as exc:
        raise HTTPException(503, f"无法连接 ComfyUI：{url}") from exc
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:2000]
        raise HTTPException(exc.response.status_code, detail) from exc


class SubmitRequest(BaseModel):
    workflow: str
    prompt: str = ""
    negative_prompt: str = ""
    seed: int | None = None
    steps: int | None = None


@app.get("/", response_class=HTMLResponse)
async def index():
    return FileResponse(BASE_DIR / "app" / "static" / "index.html")


@app.get("/api/config")
async def get_config():
    visible = {
        "title": CONFIG.get("title"),
        "poll_interval_ms": CONFIG.get("poll_interval_ms", 1500),
        "workflows": {
            name: {"label": cfg.get("label", name), "server": cfg.get("server")}
            for name, cfg in CONFIG.get("workflows", {}).items()
        }
    }
    return visible


@app.get("/api/health")
async def health():
    result = {}
    for kind in ("image", "video"):
        url = server_url(kind)
        try:
            data = await comfy_json("GET", f"{url}/system_stats")
            result[kind] = {"ok": True, "url": url, "stats": data}
        except HTTPException as exc:
            result[kind] = {"ok": False, "url": url, "error": exc.detail}
    return result


@app.post("/api/submit")
async def submit(req: SubmitRequest):
    cfg = workflow_cfg(req.workflow)
    workflow = copy.deepcopy(load_workflow(cfg))
    values = req.model_dump(exclude={"workflow"}, exclude_none=True)

    for field, value in values.items():
        mapping = cfg.get("fields", {}).get(field)
        if mapping is not None and value != "":
            set_mapped_value(workflow, mapping, value)

    client_id = str(uuid.uuid4())
    target = server_url(cfg["server"])
    payload = {"prompt": workflow, "client_id": client_id}
    queued = await comfy_json("POST", f"{target}/prompt", json=payload)
    return {
        "workflow": req.workflow,
        "server": cfg["server"],
        "prompt_id": queued["prompt_id"],
        "queue_number": queued.get("number"),
        "client_id": client_id,
    }


@app.post("/api/submit-image")
async def submit_image(
    workflow: str = Form(...),
    prompt: str = Form(""),
    seed: int | None = Form(None),
    image: UploadFile = File(...),
):
    cfg = workflow_cfg(workflow)
    if "upload_field" not in cfg:
        raise HTTPException(422, "该工作流没有配置图片输入")

    target = server_url(cfg["server"])
    file_bytes = await image.read()
    if len(file_bytes) > 50 * 1024 * 1024:
        raise HTTPException(413, "图片不能超过 50 MB")

    safe_name = f"{uuid.uuid4().hex}_{Path(image.filename or 'input.png').name}"
    files = {"image": (safe_name, file_bytes, image.content_type or "application/octet-stream")}
    data = {"type": "input", "overwrite": "true"}

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            uploaded = await client.post(f"{target}/upload/image", files=files, data=data)
            uploaded.raise_for_status()
            upload_info = uploaded.json()
    except httpx.HTTPError as exc:
        raise HTTPException(502, f"上传图片到 ComfyUI 失败：{exc}") from exc

    wf = copy.deepcopy(load_workflow(cfg))
    set_mapped_value(wf, cfg["upload_field"], upload_info["name"])

    if prompt and cfg.get("fields", {}).get("prompt"):
        set_mapped_value(wf, cfg["fields"]["prompt"], prompt)
    if seed is not None and cfg.get("fields", {}).get("seed"):
        set_mapped_value(wf, cfg["fields"]["seed"], seed)

    client_id = str(uuid.uuid4())
    queued = await comfy_json(
        "POST", f"{target}/prompt", json={"prompt": wf, "client_id": client_id}
    )
    return {
        "workflow": workflow,
        "server": cfg["server"],
        "prompt_id": queued["prompt_id"],
        "queue_number": queued.get("number"),
        "client_id": client_id,
        "uploaded": upload_info,
    }


def collect_outputs(history_item: dict[str, Any], kind: str) -> list[dict[str, Any]]:
    files: list[dict[str, Any]] = []
    outputs = history_item.get("outputs", {})
    for node_id, node_output in outputs.items():
        for category in ("images", "gifs", "videos", "audio"):
            for item in node_output.get(category, []) or []:
                if not isinstance(item, dict) or "filename" not in item:
                    continue
                filename = item["filename"]
                ext = Path(filename).suffix.lower()
                media_type = "video" if ext in {".mp4", ".webm", ".mov", ".mkv"} else "image"
                query = urlencode({
                    "server": kind,
                    "filename": filename,
                    "subfolder": item.get("subfolder", ""),
                    "type": item.get("type", "output"),
                })
                files.append({
                    "node_id": node_id,
                    "media_type": media_type,
                    "filename": filename,
                    "url": f"/api/media?{query}",
                })
    return files


@app.get("/api/job/{server_kind}/{prompt_id}")
async def job(server_kind: str, prompt_id: str):
    if server_kind not in {"image", "video"}:
        raise HTTPException(400, "server_kind 必须是 image 或 video")
    target = server_url(server_kind)
    history = await comfy_json("GET", f"{target}/history/{prompt_id}")
    item = history.get(prompt_id)
    if not item:
        queue = await comfy_json("GET", f"{target}/queue")
        running = any(str(row[1]) == prompt_id for row in queue.get("queue_running", []))
        pending = any(str(row[1]) == prompt_id for row in queue.get("queue_pending", []))
        return {"done": False, "running": running, "pending": pending, "outputs": []}

    status = item.get("status", {})
    return {
        "done": bool(status.get("completed", True)),
        "status": status,
        "outputs": collect_outputs(item, server_kind),
    }


@app.get("/api/media")
async def media(server: str, filename: str, subfolder: str = "", type: str = "output"):
    if server not in {"image", "video"}:
        raise HTTPException(400, "server 必须是 image 或 video")
    target = server_url(server)
    params = {"filename": filename, "subfolder": subfolder, "type": type}
    try:
        async with httpx.AsyncClient(timeout=120, follow_redirects=True) as client:
            response = await client.get(f"{target}/view", params=params)
            response.raise_for_status()
    except httpx.HTTPError as exc:
        raise HTTPException(502, f"读取生成文件失败：{exc}") from exc
    content_type = response.headers.get("content-type") or mimetypes.guess_type(filename)[0]
    return Response(response.content, media_type=content_type or "application/octet-stream")


@app.post("/api/interrupt/{server_kind}")
async def interrupt(server_kind: str):
    if server_kind not in {"image", "video"}:
        raise HTTPException(400, "server_kind 必须是 image 或 video")
    target = server_url(server_kind)
    return await comfy_json("POST", f"{target}/interrupt", json={})
