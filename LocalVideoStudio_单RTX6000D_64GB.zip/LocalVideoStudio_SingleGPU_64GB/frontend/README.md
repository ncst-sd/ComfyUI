# ComfyUI 独立生成前端

这是 Ubuntu 单 GPU ComfyUI 部署的附加前端。浏览器打开后可以：

- 输入 Prompt 并提交文生图/文生视频任务
- 上传图片并提交图生视频任务
- 显示 本地 ComfyUI 的在线状态
- 查询队列与完成状态
- 直接显示生成图片
- 使用 HTML5 播放器显示 MP4/WebM 视频
- 中断当前 ComfyUI 任务

ComfyUI 本地服务提供 `/prompt`、`/history/{prompt_id}`、`/view`、
`/upload/image` 和 `/interrupt` 等接口；本前端通过后端代理这些接口，
因此浏览器不需要直接访问 ComfyUI，也避免跨域问题。

## 1. 安装

假设此前的 ComfyUI 安装目录是：

```text
/opt/comfyui-video/
```

把本目录复制到：

```text
/opt/comfyui-video/frontend/
```

执行：

```bash
cd /opt/comfyui-video/frontend
cp config.example.json config.json
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 2. 必须导出三个 API 工作流

在 ComfyUI 中完成工作流后，开启开发者模式，然后选择：

```text
Save (API Format)
```

分别保存为：

```text
workflows/multiview_api.json
workflows/image_to_video_api.json
workflows/text_to_video_api.json
```

普通的 ComfyUI UI 工作流 JSON 不能直接用于 `/prompt`，必须是 API Format。

## 3. 配置节点映射

打开 API JSON，找到需要由网页修改的节点 ID，例如：

```json
"6": {
  "class_type": "CLIPTextEncode",
  "inputs": {
    "text": "原始提示词"
  }
}
```

那么 `config.json` 中写：

```json
"prompt": {
  "node": "6",
  "input": "text"
}
```

图生视频的 LoadImage 节点例如：

```json
"12": {
  "class_type": "LoadImage",
  "inputs": {
    "image": "example.png"
  }
}
```

对应：

```json
"upload_field": {
  "node": "12",
  "input": "image"
}
```

必须替换 `PROMPT_NODE_ID`、`SAMPLER_NODE_ID` 等占位符，否则提交时会明确报错。

## 4. 启动

```bash
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

浏览器访问：

```text
http://服务器IP:8080
```

## 5. 后台运行

修改 `systemd/comfyui-frontend.service` 中的用户名，然后：

```bash
sudo cp systemd/comfyui-frontend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now comfyui-frontend
journalctl -u comfyui-frontend -f
```

## 6. Nginx 反向代理与上传大小

生产环境建议只公开前端 8080 或通过 Nginx 代理，不要把 8188/8189 暴露到公网。
若使用 Nginx，应设置：

```nginx
client_max_body_size 50M;
proxy_read_timeout 3600s;
```

## 7. 当前进度方式

前端通过 `/history/{prompt_id}` 和 `/queue` 轮询状态。页面上的进度条在任务执行期间是状态估计，
不是扩散步数的精确百分比。精确步数进度可进一步接入 ComfyUI `/ws` WebSocket。
