#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/opt/comfyui-video/frontend}"
PYTHON="${PYTHON:-python3.11}"
cd "$BASE"
[[ -f config.json ]] || cp config.example.json config.json
"$PYTHON" -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo "安装完成。编辑 config.json 和 workflows/*.json 后运行："
echo "$BASE/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8080"
