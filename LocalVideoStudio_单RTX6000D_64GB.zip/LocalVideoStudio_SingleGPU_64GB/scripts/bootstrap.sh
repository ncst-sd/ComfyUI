#!/usr/bin/env bash
set -euo pipefail

ROOT="${INSTALL_ROOT:-/opt/local-video-studio}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_USER="${SUDO_USER:-$USER}"

if [[ $EUID -ne 0 ]]; then
  echo "请使用 sudo 运行：sudo ./scripts/bootstrap.sh"
  exit 1
fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  git git-lfs curl wget unzip ffmpeg build-essential pkg-config \
  software-properties-common libgl1 libglib2.0-0 libsm6 libxext6 libxrender1

if ! command -v python3.11 >/dev/null 2>&1; then
  add-apt-repository -y ppa:deadsnakes/ppa
  apt-get update
  apt-get install -y python3.11 python3.11-venv python3.11-dev
fi

if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "未检测到 nvidia-smi。请先安装 NVIDIA 驱动。"
  exit 2
fi

GPU_COUNT="$(nvidia-smi --query-gpu=index --format=csv,noheader | wc -l)"
if [[ "$GPU_COUNT" -lt 1 ]]; then
  echo "没有检测到可用 NVIDIA GPU。"
  exit 3
fi

GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)"
GPU_MEM_MIB="$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -n1 | tr -d ' ')"
RAM_GIB="$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)"
echo "检测到 GPU：$GPU_NAME，显存约 $((GPU_MEM_MIB/1024)) GiB；系统内存约 ${RAM_GIB} GiB。"
if [[ "$RAM_GIB" -lt 56 ]]; then
  echo "警告：系统内存低于 56GiB，视频任务应使用 fallback 模型和 33 帧配置。"
fi

mkdir -p "$ROOT"
chown -R "$APP_USER:$APP_USER" "$ROOT"

sudo -u "$APP_USER" bash <<EOF2
set -euo pipefail
cd "$ROOT"
if [[ ! -d ComfyUI/.git ]]; then
  git clone https://github.com/Comfy-Org/ComfyUI.git
else
  git -C ComfyUI pull --ff-only
fi
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
pip install -r ComfyUI/requirements.txt

NODES="$ROOT/ComfyUI/custom_nodes"
mkdir -p "\$NODES"
repos=(
  https://github.com/Comfy-Org/ComfyUI-Manager.git
  https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git
  https://github.com/kijai/ComfyUI-KJNodes.git
  https://github.com/Kosinkadink/ComfyUI-Advanced-ControlNet.git
  https://github.com/ltdrdata/ComfyUI-Impact-Pack.git
  https://github.com/kijai/ComfyUI-WanVideoWrapper.git
)
for repo in "\${repos[@]}"; do
  name="\$(basename "\$repo" .git)"
  if [[ -d "\$NODES/\$name/.git" ]]; then
    git -C "\$NODES/\$name" pull --ff-only
  else
    git clone --depth 1 "\$repo" "\$NODES/\$name"
  fi
  if [[ -f "\$NODES/\$name/requirements.txt" ]]; then
    pip install -r "\$NODES/\$name/requirements.txt"
  fi
done

mkdir -p ComfyUI/output/views ComfyUI/output/videos ComfyUI/input \
  ComfyUI/models/diffusion_models ComfyUI/models/text_encoders \
  ComfyUI/models/vae ComfyUI/models/clip_vision \
  ComfyUI/models/checkpoints ComfyUI/models/controlnet logs config

rm -rf "$ROOT/frontend"
cp -a "$SRC/frontend" "$ROOT/frontend"
cd "$ROOT/frontend"
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp -n config.example.json config.json || true

cp -a "$SRC/scripts" "$ROOT/"
cp -a "$SRC/config/." "$ROOT/config/"
EOF2

cat > "$ROOT/config/runtime.env" <<EOF2
INSTALL_ROOT=$ROOT
APP_USER=$APP_USER
GPU_INDEX=0
COMFY_PORT=8188
FRONTEND_PORT=8080
GPU_NAME=$GPU_NAME
GPU_MEMORY_MIB=$GPU_MEM_MIB
SYSTEM_RAM_GIB=$RAM_GIB
EOF2

# 单实例：前端的 image/video 都指向同一个本地 ComfyUI。
python3 - "$ROOT/frontend/config.json" <<'PY'
import json, sys
p=sys.argv[1]
data=json.load(open(p,encoding='utf-8'))
data['image_server']='http://127.0.0.1:8188'
data['video_server']='http://127.0.0.1:8188'
json.dump(data,open(p,'w',encoding='utf-8'),ensure_ascii=False,indent=2)
PY

sed "s|__ROOT__|$ROOT|g; s|__USER__|$APP_USER|g" "$SRC/systemd/local-video-comfyui.service" > /etc/systemd/system/local-video-comfyui.service
sed "s|__ROOT__|$ROOT|g; s|__USER__|$APP_USER|g" "$SRC/systemd/local-video-frontend.service" > /etc/systemd/system/local-video-frontend.service
systemctl daemon-reload

echo "安装完成。下一步："
echo "export HF_TOKEN=hf_xxx"
echo "sudo -E $ROOT/scripts/download_models.sh recommended"
echo "sudo systemctl enable --now local-video-comfyui local-video-frontend"
