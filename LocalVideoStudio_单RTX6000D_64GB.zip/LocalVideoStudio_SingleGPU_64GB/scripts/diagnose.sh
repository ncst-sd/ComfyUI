#!/usr/bin/env bash
set -euo pipefail
ROOT="${INSTALL_ROOT:-/opt/local-video-studio}"
echo '=== GPU ==='
nvidia-smi --query-gpu=index,name,memory.total,driver_version,utilization.gpu,memory.used --format=csv
echo '=== RAM / Swap ==='
free -h
echo '=== Disk ==='
df -h "$ROOT" || true
echo '=== Torch ==='
source "$ROOT/venv/bin/activate"
python - <<'PY'
import torch
print('torch:',torch.__version__)
print('cuda runtime:',torch.version.cuda)
print('available:',torch.cuda.is_available())
if torch.cuda.is_available():
 p=torch.cuda.get_device_properties(0)
 print('gpu:',p.name)
 print('vram GiB:',round(p.total_memory/1024**3,1))
 print('compute capability:',f'{p.major}.{p.minor}')
PY
echo '=== Services ==='
systemctl --no-pager --full status local-video-comfyui local-video-frontend || true
