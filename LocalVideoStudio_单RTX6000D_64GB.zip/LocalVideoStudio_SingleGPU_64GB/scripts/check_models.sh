#!/usr/bin/env bash
set -euo pipefail
ROOT="${INSTALL_ROOT:-/opt/local-video-studio}"
BASE="$ROOT/ComfyUI/models"
required=(
  "checkpoints/flux1-schnell-fp8.safetensors"
  "text_encoders/clip_l.safetensors"
  "text_encoders/t5xxl_fp8_e4m3fn.safetensors"
  "diffusion_models/wan2.2_ti2v_5B_fp16.safetensors"
  "text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"
  "vae/wan2.2_vae.safetensors"
)
failed=0
for f in "${required[@]}"; do
  if [[ -s "$BASE/$f" ]]; then
    printf 'OK      %s\n' "$f"
  else
    printf 'MISSING %s\n' "$f"
    failed=1
  fi
done
exit "$failed"
