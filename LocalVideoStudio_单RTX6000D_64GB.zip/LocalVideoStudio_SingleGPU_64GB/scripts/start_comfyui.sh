#!/usr/bin/env bash
set -euo pipefail
ROOT="${INSTALL_ROOT:-/opt/local-video-studio}"
source "$ROOT/config/runtime.env" 2>/dev/null || true
cd "$ROOT"
source venv/bin/activate
export CUDA_VISIBLE_DEVICES="${GPU_INDEX:-0}"
export PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True"
exec python ComfyUI/main.py \
  --listen 127.0.0.1 \
  --port "${COMFY_PORT:-8188}" \
  --preview-method auto \
  --force-fp16 \
  --disable-auto-launch
