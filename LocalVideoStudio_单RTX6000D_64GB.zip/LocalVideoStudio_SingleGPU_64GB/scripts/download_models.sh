#!/usr/bin/env bash
set -euo pipefail
ROOT="${INSTALL_ROOT:-/opt/local-video-studio}"
MODE="${1:-recommended}"

source "$ROOT/venv/bin/activate"
pip install --upgrade "huggingface_hub[cli]"
DM="$ROOT/ComfyUI/models/diffusion_models"
TE="$ROOT/ComfyUI/models/text_encoders"
VAE="$ROOT/ComfyUI/models/vae"
CKPT="$ROOT/ComfyUI/models/checkpoints"
mkdir -p "$DM" "$TE" "$VAE" "$CKPT"

hf_download() {
  local repo="$1" file="$2" dest="$3"
  echo "下载：$repo / $file"
  local args=(download "$repo" "$file" --local-dir "$(dirname "$dest")")
  [[ -n "${HF_TOKEN:-}" ]] && args+=(--token "$HF_TOKEN")
  hf "${args[@]}"
  local got="$(dirname "$dest")/$file"
  if [[ "$got" != "$dest" && -f "$got" ]]; then
    mkdir -p "$(dirname "$dest")"
    mv "$got" "$dest"
  fi
}

# 公共文本编码器和 VAE
hf_download comfyanonymous/flux_text_encoders clip_l.safetensors "$TE/clip_l.safetensors"
hf_download comfyanonymous/flux_text_encoders t5xxl_fp8_e4m3fn.safetensors "$TE/t5xxl_fp8_e4m3fn.safetensors"

# 默认图片模型：快速、许可宽松、对单卡和 64GB RAM 更稳。
hf_download Comfy-Org/flux1-schnell flux1-schnell-fp8.safetensors "$CKPT/flux1-schnell-fp8.safetensors" || true

# 默认视频模型：同一 5B 模型覆盖 T2V / I2V，避免同时保存和加载两套 14B。
hf_download Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors \
  "$DM/wan2.2_ti2v_5B_fp16.safetensors"
hf_download Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors \
  "$TE/umt5_xxl_fp8_e4m3fn_scaled.safetensors"
hf_download Comfy-Org/Wan_2.2_ComfyUI_Repackaged \
  split_files/vae/wan2.2_vae.safetensors \
  "$VAE/wan2.2_vae.safetensors"

if [[ "$MODE" == "fallback" ]]; then
  hf_download Comfy-Org/Wan_2.1_ComfyUI_repackaged \
    split_files/diffusion_models/wan2.1_t2v_1.3B_fp16.safetensors \
    "$DM/wan2.1_t2v_1.3B_fp16.safetensors" || true
fi

if [[ "$MODE" == "quality-image" ]]; then
  if [[ -z "${HF_TOKEN:-}" ]]; then
    echo "FLUX.1-dev 需要 HF_TOKEN，并需先接受模型许可。"
    exit 2
  fi
  hf_download black-forest-labs/FLUX.1-dev flux1-dev.safetensors "$DM/flux1-dev.safetensors"
  hf_download black-forest-labs/FLUX.1-dev ae.safetensors "$VAE/ae.safetensors"
fi

echo "模型下载完成。运行 $ROOT/scripts/check_models.sh"
