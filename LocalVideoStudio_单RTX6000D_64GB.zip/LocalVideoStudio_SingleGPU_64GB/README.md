# Local Video Studio — Ubuntu 20.04 / 单 RTX 6000D / 64GB 内存

这是按 **一张 NVIDIA RTX 6000D + 64GB 系统内存** 重构的完全本地图像与视频生成工作站。

## 架构变化

旧版的两个 ComfyUI 实例已取消。新版只运行一个实例：

```text
网页 :8080
   ↓
ComfyUI :8188
   ↓
单张 GPU 0
```

图片和视频任务进入同一个队列，顺序执行。这样不会让 FLUX 和 Wan 同时常驻显存与系统内存，适合 64GB RAM。

## 默认模型

### 文生图和四视角：FLUX.1 Schnell FP8

- 约 17GB checkpoint；
- 4 步即可生成，速度快；
- Apache 2.0；
- 默认 1024×1024；
- 四个视角使用四个 Prompt 分支依次生成，避免 batch=4 瞬时占用过高。

可选高质量图片模型：FLUX.1-dev，但不默认下载。它需要接受 Hugging Face 许可，并有非商业使用限制。

### 图生视频和文生视频：Wan2.2 TI2V 5B FP16

同一个 5B 模型覆盖：

- 文本直接生成视频；
- 上传图片生成视频；
- 关键帧生成视频。

默认参数：

```yaml
resolution: 832x480
frames: 49
fps: 16
steps: 20
```

稳定后可尝试 81 帧。64GB 系统内存下不建议默认安装 Wan 14B 高/低噪双模型。

### 保底模型

当 5B 仍触发 RAM/OOM 时，可下载 Wan2.1 1.3B：

```bash
sudo -E /opt/local-video-studio/scripts/download_models.sh fallback
```

建议 512×288 或 640×384、33–49 帧。

## 集成功能

- 中文/英文 Prompt 文生图；
- 正面、左侧、背面、四分之三视角；
- 网页显示图片并人工选择；
- 上传图片生成视频；
- 文本直接生成视频；
- 网页播放 MP4/WebM；
- 队列状态、任务中断、服务健康检查；
- 本地模型、本地推理、本地输出；
- systemd 开机启动；
- 模型下载、完整性检查和硬件诊断脚本。

## 安装

```bash
unzip LocalVideoStudio_单RTX6000D_64GB.zip
cd LocalVideoStudio_SingleGPU_64GB
chmod +x scripts/*.sh
sudo ./scripts/bootstrap.sh
```

默认安装目录：

```text
/opt/local-video-studio
```

安装脚本会读取实际 GPU 名称、显存和系统内存，不假定 RTX 6000D 的具体显存容量。

## 下载推荐模型

```bash
sudo -E /opt/local-video-studio/scripts/download_models.sh recommended
/opt/local-video-studio/scripts/check_models.sh
```

推荐模型均可公开下载；只有安装可选 FLUX.1-dev 时才需要：

```bash
export HF_TOKEN=hf_xxx
sudo -E /opt/local-video-studio/scripts/download_models.sh quality-image
```

## 启动

```bash
sudo systemctl enable --now local-video-comfyui local-video-frontend
```

访问：

```text
网页工作台：http://服务器IP:8080
ComfyUI：http://服务器IP:8188
```

ComfyUI 只监听 `127.0.0.1:8188`，默认不直接暴露到局域网；网页前端负责代理生成请求和媒体文件。

## 查看状态

```bash
/opt/local-video-studio/scripts/diagnose.sh
journalctl -u local-video-comfyui -f
journalctl -u local-video-frontend -f
```

## 64GB 内存优化原则

1. 图片和视频不并行执行。
2. 视频首轮使用 832×480、49 帧。
3. 不把四视角设成一次 batch=4，而是四个顺序任务。
4. 关闭浏览器之外的 GPU 程序。
5. 建议配置 32–64GB swap，防止模型切换时进程被 OOM killer 直接终止；swap 只用于容错，不会提高生成速度。
6. 视频生成完成后再运行图片任务，模型会按 ComfyUI 的显存管理机制卸载/换入。

创建 swap 示例：

```bash
sudo fallocate -l 32G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

## 工作流说明

包中保留三个前端工作流槽位：

```text
frontend/workflows/multiview_api.json
frontend/workflows/image_to_video_api.json
frontend/workflows/text_to_video_api.json
```

ComfyUI 节点和官方模板会持续变化，因此占位工作流需要在安装后，从当前版本的 Workflow Templates 加载 FLUX Schnell 和 Wan2.2 5B 模板，再使用 `Save (API Format)` 覆盖对应文件，并在 `frontend/config.json` 填入 Prompt、Seed、Steps、LoadImage 节点 ID。

这一步不能安全地用旧节点 ID 固化，否则节点升级后前端会提交失败。前端会对缺失节点或输入字段给出明确报错。

## 离线运行

首次安装、节点和模型下载完成后，整个系统可以断网运行。前端只访问：

```text
127.0.0.1:8188
```
